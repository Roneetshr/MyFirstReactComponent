import React, { Component } from 'react';
import { Button, View, Text } from 'react-native';


class AnyColorButton extends Component {
  displayAlert= ()=>{
  alert("You have a virus")  
  }
  render(){
    return(
      <Button title="Dont Click Me" 
      color={this.props.color} 
      onPress={this.displayAlert} />
      
    )
  }
}

export default class App extends Component {
  
  render() {
    return (
      <View style={{marginTop: 550}}>
        <AnyColorButton color="purple" />
        <Text>My First React Component</Text>
      </View>
    );
  }
}